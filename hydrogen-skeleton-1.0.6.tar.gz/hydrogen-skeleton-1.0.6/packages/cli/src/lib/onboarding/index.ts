export {setupLocalStarterTemplate} from './local.js';
export {setupRemoteTemplate} from './remote.js';
export type {InitOptions} from './common.js';
