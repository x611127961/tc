export function Layout(props: {children: React.ReactNode}) {
  return <div className="hydrogen-virtual-route">{props.children}</div>;
}
