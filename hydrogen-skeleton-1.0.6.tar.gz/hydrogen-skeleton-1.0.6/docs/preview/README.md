# Docs Previewer

This tool makes it easier to preview reference docs that are deployed to shopify.dev.

## Usage

Run the CLI with a path to the docs metadata file, and an app will boot up rendering a preview of the docs.

```bash
node preview/bin/cli.js path/to/generated_docs_data.json
```
